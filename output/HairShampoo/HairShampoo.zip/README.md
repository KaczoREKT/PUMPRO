Aplikacja HairShampooPrediction
Środowisko uruchomienia : Windows 7 - 11 (64 bit)
Miejsce na Dysku : 70 Mb po rozpakowaniu

Metoda uruchomienia :
1. Pobierz paczkę HairShampoo.zip 
2. Uzyj narzędzia Windows "Wyodrębnij wszystko"
3. Przejdź do nowo utworzonego folderu
4. Kliknij w "HairShampoo.exe"

Problemy i błędy
1. Przy pobieraniu alpikacji moż się pojawić komunikat
"Dysk Google nie może przeskanować tego pliku w poszukiwaniu wirusów."
W tym wypadku należ nacisnąć przycisk " Pobierz mimo to"

2. Podczas uruchamiania aplikacji może pokazać się komunikat "Windows chronił Twój komputer"\
W tym wypadku kliknij "Więcej informacji" a potem "Uruchom mimo to"

